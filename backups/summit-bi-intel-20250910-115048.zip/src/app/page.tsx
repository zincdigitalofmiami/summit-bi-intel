// Root renders Dashboard directly (no redirects)
import DashboardPage from "@/app/dashboard/page";

export default function Home() {
  return <DashboardPage />;
}
