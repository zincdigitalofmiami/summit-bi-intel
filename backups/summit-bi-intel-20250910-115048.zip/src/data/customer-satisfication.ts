export const customerSatisfication = {
  positive: 0.8,
  neutral: 0.15,
  negative: 0.05,
};

export const totalCustomers = 156;
