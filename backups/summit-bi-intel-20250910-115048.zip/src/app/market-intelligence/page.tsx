export { default } from "@/app/analytics/market-intelligence/page";

