import type { IconSvgProps } from "@/types/types";

export const VisActorLogo: React.FC<IconSvgProps> = ({
  size = 28,
  width,
  height,
  ...props
}) => (
  <svg
    fill="none"
    height={size || height}
    viewBox="0 0 26 26"
    width={size || width}
    {...props}
  >
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M13 0C20.1797 0 26 5.8203 26 13C26 14.1592 25.8483 15.283 25.5636 16.3525L18.2377 4.25581H18.2291C17.5709 3.254 16.4371 2.59256 15.1489 2.59256C13.8606 2.59256 12.7268 3.254 12.0686 4.25581H12.0599L11.9686 4.41693C11.951 4.44707 11.9337 4.47747 11.9169 4.50815L3.88731 18.6779C3.56947 19.2224 3.38736 19.8558 3.38736 20.5318C3.38736 21.1089 3.52009 21.655 3.75667 22.1412C1.43409 19.7928 0 16.5639 0 13C0 5.8203 5.8203 0 13 0ZM6.27755 24.1292C6.53287 24.1852 6.79812 24.2147 7.07026 24.2147C9.10427 24.2147 10.7532 22.5658 10.7532 20.5318C10.7532 19.8794 10.5835 19.2667 10.286 18.7353L10.2879 18.7345L8.49328 15.6288C7.52634 13.954 8.10016 11.8124 9.77496 10.8455C11.4498 9.87854 13.5913 10.4524 14.5582 12.1272L20.8887 22.8559L20.8912 22.8548C20.9571 22.962 21.0284 23.0655 21.1045 23.1651C18.8821 24.9394 16.0649 26 13 26C10.5397 26 8.23908 25.3166 6.27755 24.1292Z"
      fill="#0040FF"
    ></path>
  </svg>
);

export const ZincFusionLogo: React.FC<IconSvgProps> = ({
  size = 28,
  width,
  height,
  ...props
}) => (
  <svg
    fill="none"
    height={size || height}
    viewBox="0 0 32 32"
    width={size || width}
    {...props}
  >
    {/* ZINC Fusion Logo - Modern tech design */}
    <defs>
      <linearGradient id="zincGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0ea5e9" />
        <stop offset="50%" stopColor="#3b82f6" />
        <stop offset="100%" stopColor="#6366f1" />
      </linearGradient>
    </defs>
    
    {/* Outer circle */}
    <circle
      cx="16"
      cy="16"
      r="15"
      stroke="url(#zincGradient)"
      strokeWidth="2"
      fill="none"
    />
    
    {/* Inner Z shape */}
    <path
      d="M8 10 L24 10 L24 12 L12 12 L24 22 L24 24 L8 24 L8 22 L20 22 L8 12 Z"
      fill="url(#zincGradient)"
    />
    
    {/* Fusion dots */}
    <circle cx="22" cy="8" r="1.5" fill="#0ea5e9" />
    <circle cx="26" cy="12" r="1" fill="#3b82f6" />
    <circle cx="10" cy="26" r="1.5" fill="#6366f1" />
    <circle cx="6" cy="20" r="1" fill="#0ea5e9" />
  </svg>
);
